# Personal Voice Bot with Gemini API

A modern, user-friendly voice bot that responds to personal questions using Google's Gemini AI. Features speech-to-text, text-to-speech, and a beautiful web interface.

## Features

- 🎤 **Voice Recognition**: Speak your questions naturally
- 🔊 **Text-to-Speech**: Hear responses spoken back to you
- 💬 **Text Input**: Type questions if you prefer
- 🎨 **Modern UI**: Beautiful, responsive design
- 🤖 **Gemini AI**: Powered by Google's advanced AI model
- 📱 **Mobile Friendly**: Works on all devices

## Quick Start

### 1. Get Your Gemini API Key

1. Go to [Google AI Studio](https://makersuite.google.com/app/apikey)
2. Create a new API key
3. Copy the key for the next step

### 2. Set Up Environment Variables

Create a `.env` file in the root directory:

```bash
GEMINI_API_KEY=your_actual_api_key_here
```

### 3. Install Dependencies

```bash
npm install
```

### 4. Run the Application

```bash
npm start
```

Visit `http://localhost:3000` to use your voice bot!

## Development

Run in development mode with auto-restart:

```bash
npm run dev
```

## Deployment

### Deploy to Vercel (Recommended)

1. Install Vercel CLI: `npm i -g vercel`
2. Run: `vercel`
3. Follow the prompts
4. Add your `GEMINI_API_KEY` in Vercel dashboard under Environment Variables

### Deploy to Other Platforms

The app can be deployed to:
- **Heroku**: Add `GEMINI_API_KEY` to config vars
- **Railway**: Add environment variable in dashboard
- **Render**: Set environment variable in service settings

## Customization

### Personality Prompts

Edit the `PERSONALITY_PROMPT` in `server.js` to customize how the bot responds:

```javascript
const PERSONALITY_PROMPT = `You are responding as [your description here]...`;
```

### Sample Questions

Modify the sample questions in `public/index.html`:

```html
<button class="sample-btn" data-question="Your custom question">Button Text</button>
```

### Styling

Customize the appearance by editing `public/style.css`.

## Browser Compatibility

- **Voice Recognition**: Chrome, Edge, Safari (recent versions)
- **Text-to-Speech**: All modern browsers
- **Text Input**: Universal support

## Troubleshooting

### Voice Recognition Not Working

- Ensure you're using HTTPS (required for microphone access)
- Check browser permissions for microphone
- Use Chrome or Edge for best compatibility

### API Errors

- Verify your Gemini API key is correct
- Check that your API key has proper permissions
- Ensure you haven't exceeded API quotas

## Tech Stack

- **Frontend**: HTML5, CSS3, Vanilla JavaScript
- **Backend**: Node.js, Express
- **AI**: Google Gemini API
- **Speech**: Web Speech API, Speech Synthesis API
- **Deployment**: Vercel (recommended)

## License

MIT License - feel free to use this for your projects! 